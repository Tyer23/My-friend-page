<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" >
    <meta name="description" content="Web application development" >
    <meta name="keywords" content="PHP" >
    <meta name="author" content="Quoc Co Luc (Tyler)" >
    <title>Assignment 2 - Settings</title>
</head>
<body>
    <?php
       $host = "feenix-mariadb.swin.edu.au";
       $user = "s103830572"; // your user name
       $pswd = "wobaimenTA@2001"; // your password 
       $dbnm = "s103830572_db"; // your database
    ?>
</body>
</html>